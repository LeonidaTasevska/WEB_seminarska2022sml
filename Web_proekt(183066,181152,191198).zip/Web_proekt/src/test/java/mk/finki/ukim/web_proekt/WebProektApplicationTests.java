package mk.finki.ukim.web_proekt;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WebProektApplicationTests {

    @Test
    void contextLoads() {
    }

}
