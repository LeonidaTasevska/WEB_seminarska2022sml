package mk.finki.ukim.web_proekt.model.exceptions;

public class InvalidUsernameOrPasswordException extends RuntimeException{
}
