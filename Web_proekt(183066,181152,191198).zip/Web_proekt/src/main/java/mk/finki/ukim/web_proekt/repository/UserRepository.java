package mk.finki.ukim.web_proekt.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Repository;
import mk.finki.ukim.web_proekt.model.User;

import java.util.Optional;

@Repository
public interface UserRepository extends JpaRepository<User,Long> {

    Optional<UserDetails> findByUsername(String username);
    Optional<User> findByUsernameAndPassword(String username,String password);
}
