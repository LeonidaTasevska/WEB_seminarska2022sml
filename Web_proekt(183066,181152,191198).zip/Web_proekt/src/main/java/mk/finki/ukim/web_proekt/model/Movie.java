package mk.finki.ukim.web_proekt.model;

import lombok.Data;

import javax.persistence.*;


@Data
@Entity
public class Movie {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long id;

    private String name;

    private String producentskaKukja;

    @Column(length = 1000)
    private String description;

    @ManyToOne
    private Author author;

    private Double price;

    private String zanr;

    private Integer votes;

    @Basic(fetch = FetchType.LAZY)
    private String picturePath;

    private Integer couponsForMovie;

    @Transient
    public String getPicturePath() {
        if (picturePath== null || id == null) return null;

        return "/book-photos/" + id + "/" + picturePath;
    }

    public Movie() {
    }

    public Movie(String name, Author author ,String izdavac,String description,
                String zanr,Double price,Integer coupons,String picturePath) {
        this.name = name;
        this.author=author;
        this.producentskaKukja=izdavac;
        this.price=price;
        this.zanr=zanr;
        this.picturePath=picturePath;
        this.description=description;
        this.couponsForMovie=coupons;
        votes=0;
    }
}


