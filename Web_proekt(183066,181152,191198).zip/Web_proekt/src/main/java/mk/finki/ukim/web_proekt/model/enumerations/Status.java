package mk.finki.ukim.web_proekt.model.enumerations;

public enum Status {

    CREATED,
    CANCELED,
    FINISHED

}
