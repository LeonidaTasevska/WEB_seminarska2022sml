package mk.finki.ukim.web_proekt.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import mk.finki.ukim.web_proekt.model.Bundle;

@Repository
public interface BundleRepository extends JpaRepository<Bundle,Long> {
}
