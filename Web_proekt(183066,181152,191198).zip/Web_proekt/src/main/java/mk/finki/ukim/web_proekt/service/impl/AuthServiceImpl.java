package mk.finki.ukim.web_proekt.service.impl;

import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import mk.finki.ukim.web_proekt.model.User;
import mk.finki.ukim.web_proekt.model.exceptions.InvalidArgumentsException;
import mk.finki.ukim.web_proekt.model.exceptions.InvalidUserCredentialsException;
import mk.finki.ukim.web_proekt.repository.UserRepository;
import mk.finki.ukim.web_proekt.service.AuthService;

@Service
public class AuthServiceImpl implements AuthService {

    private final UserRepository userRepository;
    private final PasswordEncoder passwordEncoder;

    public AuthServiceImpl(UserRepository userRepository,PasswordEncoder passwordEncoder) {
        this.passwordEncoder=passwordEncoder;
        this.userRepository = userRepository;
    }

    @Override
    public User login(String username, String password) {
        if (username==null || username.isEmpty() || password==null || password.isEmpty()) {
            throw new InvalidArgumentsException();
        }
        return userRepository.findByUsernameAndPassword(username,
                password).orElseThrow(InvalidUserCredentialsException::new);
    }

}
