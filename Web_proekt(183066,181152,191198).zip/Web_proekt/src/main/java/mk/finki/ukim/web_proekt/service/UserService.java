package mk.finki.ukim.web_proekt.service;

import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import mk.finki.ukim.web_proekt.model.User;
import mk.finki.ukim.web_proekt.model.enumerations.Role;

public interface UserService extends UserDetailsService {

    User register(String username, String password,
                  String repeatPassword, String name, String surname, Role role);

    UserDetails loadUserByUsername(String s) throws UsernameNotFoundException;

    User findByUsername(String username);

    void calculateCoupons(Integer useCoupons,User user);


}
