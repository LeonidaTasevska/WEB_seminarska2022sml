package mk.finki.ukim.web_proekt.service.impl;

import org.springframework.stereotype.Service;
import mk.finki.ukim.web_proekt.model.Movie;
import mk.finki.ukim.web_proekt.model.ShoppingCart;
import mk.finki.ukim.web_proekt.model.User;
import mk.finki.ukim.web_proekt.model.enumerations.Status;
import mk.finki.ukim.web_proekt.model.exceptions.MovieAlreadyInShoppingCartException;
import mk.finki.ukim.web_proekt.model.exceptions.MovieNotFoundException;
import mk.finki.ukim.web_proekt.model.exceptions.ShoppingCartNotFoundException;
import mk.finki.ukim.web_proekt.model.exceptions.UserNotFoundException;
import mk.finki.ukim.web_proekt.repository.ShoppingCartRepository;
import mk.finki.ukim.web_proekt.repository.UserRepository;
import mk.finki.ukim.web_proekt.service.MovieService;
import mk.finki.ukim.web_proekt.service.ShoppingCartService;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class ShoppingCartServiceImpl implements ShoppingCartService {

    private final ShoppingCartRepository shoppingCartRepository;
    private final UserRepository userRepository;
    private final MovieService movieService;

    public ShoppingCartServiceImpl(ShoppingCartRepository shoppingCartRepository,
                                   UserRepository userRepository,
                                   MovieService movieService) {
        this.shoppingCartRepository = shoppingCartRepository;
        this.userRepository = userRepository;
        this.movieService = movieService;
    }

    @Override
    public List<Movie> listAllMoviesInShoppingCart(Long cartId) {
        if(!this.shoppingCartRepository.findById(cartId).isPresent())
            throw new ShoppingCartNotFoundException(cartId);
        return this.shoppingCartRepository.findById(cartId).get().getMovieList();
    }

    @Override
    public ShoppingCart getActiveShoppingCart(String username) {
        User user = (User) this.userRepository.findByUsername(username)
                .orElseThrow(() -> new UserNotFoundException(username));

        return this.shoppingCartRepository
                .findByUserAndStatus(user, Status.CREATED)
            .orElseGet(() -> {
                    ShoppingCart cart = new ShoppingCart(user);
                    return this.shoppingCartRepository.save(cart);
                });
    }

    @Override
    public ShoppingCart addMovieToShoppingCart(String username, Long movieId) {
        ShoppingCart shoppingCart = this.getActiveShoppingCart(username);
        Movie movie = this.movieService.findById(movieId)
                .orElseThrow(() -> new MovieNotFoundException(movieId));
        if(shoppingCart.getMovieList()
                .stream().filter(i -> i.getId().equals(movieId))
                .collect(Collectors.toList()).size() > 0)
            throw new MovieAlreadyInShoppingCartException(movieId, username);
        shoppingCart.getMovieList().add(movie);
        return this.shoppingCartRepository.save(shoppingCart);
    }

    @Override
    public void deleteMovieFromShoppingCart(String username,Long movieId) {
        ShoppingCart shoppingCart = this.getActiveShoppingCart(username);
        shoppingCart.getMovieList().removeIf(
                r-> r.getId().equals(movieId));
        this.shoppingCartRepository.save(shoppingCart);
    }

}
