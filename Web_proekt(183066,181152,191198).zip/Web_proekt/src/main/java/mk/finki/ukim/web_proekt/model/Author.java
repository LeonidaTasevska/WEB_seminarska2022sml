package mk.finki.ukim.web_proekt.model;

import lombok.Data;

import javax.persistence.*;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

@Data
@Entity
public class Author {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String name;

    private String surname;

    private Date birthDate;

    private String country;

    @OneToMany(mappedBy = "author")
    private List<Movie> movies;

    public Author(){}

    public Author(String name, String surname,Date birthDate,String country) {
        this.name = name;
        this.surname = surname;
        this.birthDate=birthDate;
        this.movies=new ArrayList<>();
        this.country=country;
    }

}
