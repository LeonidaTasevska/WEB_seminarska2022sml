package mk.finki.ukim.web_proekt;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class WebProektApplication {

    public static void main(String[] args) {
        SpringApplication.run(WebProektApplication.class, args);
    }

}
