package mk.finki.ukim.web_proekt.service.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.stereotype.Service;
import mk.finki.ukim.web_proekt.service.EmailService;

import javax.mail.MessagingException;

@Service
public class EmailServiceImpl implements EmailService {

    @Autowired
    private final JavaMailSender javaMailSender;


    public EmailServiceImpl(JavaMailSender javaMailSender) {
        this.javaMailSender = javaMailSender;
    }


    public void sendMail(String subject, String message1) throws MessagingException {

        SimpleMailMessage mail = new SimpleMailMessage();
        mail.setTo("proektna@gmail.com");
        mail.setSubject(subject);
        mail.setText(message1);


        javaMailSender.send(mail);
    }

}
