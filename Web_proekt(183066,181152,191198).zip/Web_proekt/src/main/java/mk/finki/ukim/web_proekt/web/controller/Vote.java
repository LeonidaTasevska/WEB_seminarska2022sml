package mk.finki.ukim.web_proekt.web.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import mk.finki.ukim.web_proekt.model.Movie;
import mk.finki.ukim.web_proekt.service.AuthorService;
import mk.finki.ukim.web_proekt.service.MovieService;

import java.util.List;

@Controller
@RequestMapping(value = {"/vote"})
public class Vote {


    private final MovieService movieService;

    public Vote(MovieService movieService, AuthorService authorService) {
        this.movieService = movieService;
    }

    @GetMapping
    public String getVotePage(Model model) {
        List<Movie> movies = this.movieService.findAll();
        model.addAttribute("movies", movies);
        return "vote";
    }

    @PostMapping("/upload")
    public String userVote(@RequestParam Long firstChoice,
                           @RequestParam Long secondChoice,
                           @RequestParam Long thirdChoice,
                           @RequestParam Long fourthChoice,
                           @RequestParam Long fifthChoice) {

        Long [] array= {firstChoice,secondChoice,thirdChoice,fourthChoice,fifthChoice};
        this.movieService.votes(array);

        return "redirect:/home";
    }

}