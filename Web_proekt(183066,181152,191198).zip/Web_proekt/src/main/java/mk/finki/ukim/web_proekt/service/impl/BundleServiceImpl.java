package mk.finki.ukim.web_proekt.service.impl;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import mk.finki.ukim.web_proekt.model.Bundle;
import mk.finki.ukim.web_proekt.model.exceptions.BundleNotFoundException;
import mk.finki.ukim.web_proekt.repository.BundleRepository;
import mk.finki.ukim.web_proekt.service.MovieService;
import mk.finki.ukim.web_proekt.service.BundleService;

import java.util.List;
import java.util.Optional;

@Service
public class BundleServiceImpl implements BundleService {

    private final BundleRepository bundleRepository;
    private final MovieService movieService;


    public BundleServiceImpl(BundleRepository bundleRepository, MovieService movieService) {
        this.bundleRepository = bundleRepository;
        this.movieService = movieService;
    }

    @Override
    public List<Bundle> findAll() {
        return this.bundleRepository.findAll();
    }

    public Optional<Bundle> findById(Long id){
      return  this.bundleRepository.findById(id);
    }

    @Override
    public void deleteById(Long id) {
        this.bundleRepository.deleteById(id);
    }

    @Override
    @Transactional
    public Optional<Bundle> save(String name,
                               String description,
                               Double price, Integer coupons, String picturePath) {

        return Optional.of(this.bundleRepository.save(new Bundle(name,
                description,price,coupons,picturePath)));
    }


    @Override
    @Transactional
    public Optional<Bundle> edit(Long id, String name,
                                 String description,
                                 Double price, Integer coupons, String picturePath) {

        Bundle bundle= this.bundleRepository.findById(id).orElseThrow(() -> new BundleNotFoundException(id));

        bundle.setName(name);
        bundle.setDescription(description);
        bundle.setPriceBundle(price);
        bundle.setCoupons(coupons);
        bundle.setBundlePicturePath(picturePath);


        return Optional.of(this.bundleRepository.save(bundle));
    }


}
