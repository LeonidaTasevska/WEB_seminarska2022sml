package mk.finki.ukim.web_proekt.web.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import mk.finki.ukim.web_proekt.model.Movie;
import mk.finki.ukim.web_proekt.service.MovieService;

@Controller
@RequestMapping
public class ViewMovie {

    private final MovieService movieService;

    public ViewMovie(MovieService movieService) {
        this.movieService = movieService;
    }

    @GetMapping("/view/{id}")
    public String getViewPage(@PathVariable Long id, Model model) {
        if (this.movieService.findById(id).isPresent()) {
            Movie movie = this.movieService.findById(id).get();
            model.addAttribute("movie", movie);
            return "view-movie";
        }
        return "redirect:/movies?error=MovieNotFound";
    }
}