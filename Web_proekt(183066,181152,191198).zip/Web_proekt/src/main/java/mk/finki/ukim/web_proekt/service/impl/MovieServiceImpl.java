package mk.finki.ukim.web_proekt.service.impl;

import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import mk.finki.ukim.web_proekt.model.Author;
import mk.finki.ukim.web_proekt.model.Movie;
import mk.finki.ukim.web_proekt.model.exceptions.AuthorNotFoundException;
import mk.finki.ukim.web_proekt.model.exceptions.MovieNotFoundException;
import mk.finki.ukim.web_proekt.repository.AuthorRepository;
import mk.finki.ukim.web_proekt.repository.MovieRepository;
import mk.finki.ukim.web_proekt.service.MovieService;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
public class MovieServiceImpl implements MovieService {

    private final MovieRepository movieRepository;
    private final AuthorRepository authorRepository;

    public MovieServiceImpl(MovieRepository movieRepository,
                           AuthorRepository authorRepository) {
        this.movieRepository = movieRepository;
        this.authorRepository = authorRepository;
    }

    @Override
    public List<Movie> findAll() {
        return this.movieRepository.findAll();
    }

    @Override
    public Optional<Movie> findById(Long id) {
        return this.movieRepository.findById(id);
    }

    @Override
    public Optional<Movie> findByName(String name) {
        return this.movieRepository.findByName(name);
    }

    @Override
    @Transactional
    public Optional<Movie> save(String name, Long authorId, String izdavac,
                               String description,String zanr,
                               Double price,Integer coupons, String picturePath) {

        Author author = this.authorRepository.findById(authorId).orElseThrow(() -> new AuthorNotFoundException(authorId));

        return Optional.of(this.movieRepository.save(new Movie(name, author,izdavac,
                description,zanr,price,coupons,picturePath)));
    }


    @Override
    @Transactional
    public Optional<Movie> edit(Long id, String name, Long authorId,String izdavac, String description,String zanr,
                               Double price,Integer coupons, String picturePath) {

        Movie movie = this.movieRepository.findById(id).orElseThrow(() -> new MovieNotFoundException(id));

        movie.setName(name);
        movie.setProducentskaKukja(izdavac);
        movie.setPrice(price);
        movie.setDescription(description);
        movie.setZanr(zanr);
        movie.setCouponsForMovie(coupons);
        movie.setPicturePath(picturePath);

        Author author = this.authorRepository.findById(authorId)
                .orElseThrow(() -> new AuthorNotFoundException(authorId));
        movie.setAuthor(author);

        return Optional.of(this.movieRepository.save(movie));
    }

    @Override
    public void deleteById(Long id) {
        this.movieRepository.deleteById(id);
    }

    @Override
    public List<Movie> findMovieByZanr(String zanr) {
        return null;
    }

    @Override
    public List<Movie> firstFiveMovies() {
        return null;
    }


    @Override
    public void votes(Long [] array) {

        Movie movie=null;

        for(Long item : array){
            movie=this.movieRepository.findById(item).get();
            Integer n=movie.getVotes();
            n=n+1;
            movie.setVotes(n);
            this.movieRepository.save(movie);
        }

    }

}
