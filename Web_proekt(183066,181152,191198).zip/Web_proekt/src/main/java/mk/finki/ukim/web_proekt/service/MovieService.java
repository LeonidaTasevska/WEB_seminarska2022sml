package mk.finki.ukim.web_proekt.service;

import mk.finki.ukim.web_proekt.model.Movie;

import java.util.List;
import java.util.Optional;

public interface MovieService {
    List<Movie> findAll();

    Optional<Movie> findById(Long id);

    Optional<Movie> findByName(String name);

    Optional<Movie> save(String name, Long author,String izdavac,String description,
                        String zanr,Double price,Integer coupons,String picturePath);


    Optional<Movie> edit(Long id, String name, Long authorId,String izdavac, String description,String zanr,
                        Double price,Integer coupons, String picturePath);

    void deleteById(Long id);

    List<Movie> findMovieByZanr(String zanr);

    List <Movie> firstFiveMovies();

    void votes(Long [] array);
}
