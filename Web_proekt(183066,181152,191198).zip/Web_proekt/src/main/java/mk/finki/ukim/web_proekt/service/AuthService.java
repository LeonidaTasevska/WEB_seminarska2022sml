package mk.finki.ukim.web_proekt.service;

import mk.finki.ukim.web_proekt.model.User;

public interface AuthService {

    User login(String username, String password);

}
