package mk.finki.ukim.web_proekt.web.controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;
import mk.finki.ukim.web_proekt.model.Author;
import mk.finki.ukim.web_proekt.model.Movie;
import mk.finki.ukim.web_proekt.service.AuthorService;
import mk.finki.ukim.web_proekt.service.MovieService;

import java.io.IOException;
import java.util.List;
import java.util.Optional;

@Controller
@RequestMapping
public class MovieController {

    private static final Logger logger = LoggerFactory.getLogger("MovieController.class");
    private final MovieService movieService;
    private final AuthorService authorService;

    public MovieController(MovieService movieService, AuthorService authorService) {
        this.movieService = movieService;
        this.authorService = authorService;
    }


    @GetMapping("/movies")
    public String getMoviePage(Model model) {
        List<Movie> movies = this.movieService.findAll();
        model.addAttribute("movies", movies);
        return "movies";
    }

    @DeleteMapping("/delete/{id}")
    public String deleteMovie(@PathVariable Long id) {
        this.movieService.deleteById(id);
        return "redirect:/movies";
    }

    @GetMapping("/edit-form/{id}")
    public String editMoviePage(@PathVariable Long id, Model model) {
        if (this.movieService.findById(id).isPresent()) {
            Movie movie = this.movieService.findById(id).get();
            List<Author> authors = this.authorService.findAll();
            model.addAttribute("authors", authors);
            model.addAttribute("movie", movie);
            return "add-movie";
        }
        return "redirect:/books?error=BookNotFound";
    }

    @GetMapping("/add-movie")
    public String getPage(Model model){
        List<Author> authors=this.authorService.findAll();
        model.addAttribute("authors",authors);
        return "add-movie";
    }

    @PostMapping("add-movie/upload")
    public String uploadImage(@RequestParam(required = false) Long id,
                              @RequestParam String movieName,
                              @RequestParam Long authorId,
                              @RequestParam String izdavac,
                              @RequestParam String description,
                              @RequestParam String zanr,
                              @RequestParam Double cena,
                              @RequestParam Integer coupons,
                              @RequestParam MultipartFile imageFile) throws IOException {


        String fileName = StringUtils.cleanPath(imageFile.getOriginalFilename());
        Optional<Movie> movie=null;
        if (id != null) {
            movie=this.movieService.edit(id, movieName,authorId,izdavac,description,zanr,cena,coupons,fileName);
        } else {
            movie=this.movieService.save(movieName,authorId,izdavac,description,zanr,cena,coupons,fileName);
        }

        String uploadDir = "movie-photos/" + movie.get().getId();

        FileUploadUtil.saveFile(uploadDir, fileName, imageFile);

        return "redirect:/movies";

    }

    @GetMapping("/{zanr}")
    public String getZanrPage(@PathVariable String zanr,Model model){
        if(!this.movieService.findMovieByZanr(zanr).isEmpty()) {
            List<Movie> movies = this.movieService.findMovieByZanr(zanr);
            model.addAttribute("movies", movies);
            return "movies";
        }
        return "redirect:/movies?error=BookNotFound";
    }

}

