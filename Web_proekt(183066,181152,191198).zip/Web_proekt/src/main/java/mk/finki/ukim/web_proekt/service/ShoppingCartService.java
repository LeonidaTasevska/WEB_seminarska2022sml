package mk.finki.ukim.web_proekt.service;

import mk.finki.ukim.web_proekt.model.Movie;
import mk.finki.ukim.web_proekt.model.ShoppingCart;

import java.util.List;

public interface ShoppingCartService {

    List<Movie> listAllMoviesInShoppingCart(Long cartId);
    ShoppingCart getActiveShoppingCart(String username);
    ShoppingCart addMovieToShoppingCart(String username, Long productId);
    void deleteMovieFromShoppingCart (String username,Long movieId);
}
